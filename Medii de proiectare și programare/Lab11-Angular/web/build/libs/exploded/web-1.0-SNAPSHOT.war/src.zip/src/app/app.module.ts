import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ClientComponent } from './client/client.component';
import { ClientDetailComponent } from './client/client-detail/client-detail.component';
import { ClientListComponent } from './client/client-list/client-list.component';
import {FormsModule} from "@angular/forms";
import {ClientService} from "./client/shared/client.service";

@NgModule({
  declarations: [
    AppComponent,
    ClientComponent,
    ClientDetailComponent,
    ClientListComponent
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [ClientService],
  bootstrap: [AppComponent]
})
export class AppModule { }
