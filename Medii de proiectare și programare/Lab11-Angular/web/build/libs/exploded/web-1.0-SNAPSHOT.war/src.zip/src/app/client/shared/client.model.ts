export class Client {
  id:number;
  id2:number;
  name:string;
  phoneNumber:string;
}
