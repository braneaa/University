import { Client.Model } from './client.model';

describe('Client.Model', () => {
  it('should create an instance', () => {
    expect(new Client.Model()).toBeTruthy();
  });
});
